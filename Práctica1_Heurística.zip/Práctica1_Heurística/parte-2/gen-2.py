#!/usr/bin/env python3
import sys
import subprocess
import re
import os

if len(sys.argv) != 3:
    print("Uso: ./gen-2.py fichero-entrada.in fichero-salida")
    sys.exit(1)

entrada = sys.argv[1]
salida = sys.argv[2]

# === 0. Ajustar la ruta de los ficheros según la carpeta de pruebas ===
# Permite buscar el fichero de entrada contiene que 'prueba-X', en la carpeta pruebas-2-2
if entrada.startswith("prueba-"):
    entrada = os.path.join("pruebas-2-2", entrada)
    salida = os.path.join("pruebas-2-2", salida)

# === 1. Leer el archivo .in ===
with open(entrada) as f:
    lines = [line.strip() for line in f if line.strip()]

# Primera línea: n franjas, m autobuses, u talleres
n, m, u = map(int, lines[0].replace(",", " ").split())

# Matriz c (pasajeros compartidos entre buses)
matriz_pasajeros_compartidos = [list(map(int, line.replace(",", " ").split())) for line in lines[1:1+m]]

# Matriz o (disponibilidad de franjas en talleres)
matriz_disponibilidad_franjas = [list(map(int, line.replace(",", " ").split())) for line in lines[1+m:1+m+n]]

# === 2. Generar el fichero .dat para GLPK ===
with open(salida, 'w') as f:
    f.write("data;\n\n")

    # Conjuntos
    buses = " ".join([f"a{i+1}" for i in range(m)])
    franjas = " ".join([f"s{i+1}" for i in range(n)])
    talleres = " ".join([f"t{i+1}" for i in range(u)])

    f.write(f"set BUSES := {buses};\n")
    f.write(f"set FRANJAS := {franjas};\n")
    f.write(f"set TALLERES := {talleres};\n\n")

    # Matriz pasajerosCompartidos
    f.write("# Por decisiones de diseño, los valores de la diagonal y por debajo de la diagonal se ignoran, ya que:\n")
    f.write("# Un autobus no puede tener conflicto consigo mismo y c[i,j] = c[j,i], respectivamente\n")
    f.write("param pasajerosCompartidos : " + buses + " :=\n")
    for i in range(m):
        f.write(f"a{i+1} " + " ".join(map(str, matriz_pasajeros_compartidos[i])) + "\n")
    f.write(";\n\n")

    # Matriz disponibilidadFranjas
    f.write("param disponibilidadFranjas : " + talleres + " :=\n")
    for i in range(n):
        f.write(f"s{i+1} " + " ".join(map(str, matriz_disponibilidad_franjas[i])) + "\n")
    f.write(";\n\nend;\n")

print(f"[OK] Fichero de datos generado: {salida}")

# === 3. Ejecutar GLPK ===
modelo = "parte-2-2.mod"
cmd = ["glpsol", "--model", modelo, "--data", salida, "-o", "sol.txt"]
subprocess.run(cmd)

# === 4. Mostrar resumen ===
try:
    with open("sol.txt") as f:
        contenido = f.read()

    rows, cols, objective = None, None, None
    for linea in contenido.splitlines():
        if linea.startswith("Rows:"):
            rows = int(linea.split()[1])
        elif linea.startswith("Columns:"):
            cols = int(linea.split()[1])
        elif "Objective:" in linea:
            objective = float(linea.split('=')[1].split()[0])

    print("\n========= RESULTADO =========\n")
    print(f"Valor óptimo: {objective}, Variables de decisión: {cols}, Restricciones totales: {rows}\n")
    print("Asignaciones de autobuses a franjas y talleres:")

    # Diccionario para almacenar asignaciones por bus
    asignaciones = {f"a{i+1}": [] for i in range(m)}

    # Leer columnas de asignacion y guardarlas para imprimir por pantalla
    lineas = contenido.splitlines()
    for i, linea in enumerate(lineas):
        # Buscamos las asignaciones en el archivo de solución de GLPK
        match = re.match(r'\s*\d+\s+asignacion\[(a\d+),(s\d+),(t\d+)\]', linea)
        if match:
            bus, franja, taller = match.groups()
            if i+1 < len(lineas):
                act_line = lineas[i+1]
                act_parts = act_line.split()
                if len(act_parts) >= 2:
                    try:
                        activity = int(act_parts[1])
                        if activity == 1:
                            asignaciones[bus].append((franja, taller))
                    except ValueError:
                        pass

    # Mostrar todas las asignaciones y los no asignados
    for bus, asigns in asignaciones.items():
        if asigns:
            for franja, taller in asigns:
                print(f"Autobús {bus} asignado a Franja {franja} en Taller {taller}")
        else:
            print(f"Autobús {bus} no asignado")

# Salta error si hay algun error en la ejecución de GLPK
except FileNotFoundError:
    print("Error: no se ha generado 'sol.txt'. Revisa errores de GLPK.")