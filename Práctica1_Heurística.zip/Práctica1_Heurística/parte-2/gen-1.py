#!/usr/bin/env python3
import sys
import subprocess
import re
import os

if len(sys.argv) != 3:
    print("Uso: ./gen-1.py fichero-entrada fichero-salida")
    sys.exit(1)

entrada = sys.argv[1]
salida = sys.argv[2]

# === 0. Ajustar la ruta de los ficheros según la carpeta de pruebas ===
# Permite buscar el fichero de entrada contiene que 'prueba-X', en la carpeta pruebas-2-1
if entrada.startswith("prueba-"):
    entrada = os.path.join("pruebas-2-1", entrada)
    salida = os.path.join("pruebas-2-1", salida)

# === 1. Leer el archivo .in ===
with open(entrada) as f:
    lines = [line.strip() for line in f if line.strip()]

# Primera línea: n franjas, m autobuses
n, m = map(int, lines[0].replace(",", " ").split())

# Segunda línea: coste_por_km (k_d), coste_por_pasajero (k_p)
coste_por_km, coste_por_pasajero = map(float, lines[1].replace(",", " ").split())

# Distancias de los autobuses
valores_distancias = list(map(float, lines[2].replace(",", " ").split()))
# Número de pasajeros por autobús
valores_pasajeros = list(map(float, lines[3].replace(",", " ").split()))

# === 2. Generar el fichero .dat para GLPK ===
with open(salida, "w") as f:
    f.write("data;\n\n")

    # Conjuntos
    buses = " ".join([f"a{i+1}" for i in range(m)])
    franjas = " ".join([f"s{i+1}" for i in range(n)])

    f.write(f"set BUSES := {buses};\n")
    f.write(f"set FRANJAS := {franjas};\n\n")

    # Parámetros constantes
    f.write(f"param coste_por_km := {coste_por_km};\n")
    f.write(f"param coste_por_pasajero := {coste_por_pasajero};\n\n")

    # Distancias
    f.write("param distancias :=\n")
    for i in range(m):
        f.write(f"a{i+1} {valores_distancias[i]}\n")
    f.write(";\n\n")

    # Pasajeros
    f.write("param pasajeros :=\n")
    for i in range(m):
        f.write(f"a{i+1} {valores_pasajeros[i]}\n")
    f.write(";\n\nend;\n")

print(f"[OK] Fichero de datos generado: {salida}")

# === 3. Ejecutar GLPK ===
modelo = "parte-2-1.mod"
cmd = ["glpsol", "--model", modelo, "--data", salida, "-o", "sol.txt"]
subprocess.run(cmd)

# === 4. Mostrar resumen ===
try:
    with open("sol.txt") as f:
        contenido = f.read()

    rows, cols, objective = None, None, None
    for linea in contenido.splitlines():
        if linea.startswith("Rows:"):
            rows = int(linea.split()[1])
        elif linea.startswith("Columns:"):
            cols = int(linea.split()[1])
        elif "Objective:" in linea:
            objective = float(linea.split('=')[1].split()[0])

    # Mostrar resultados, valor minimo, num variables de decisión y num restricciones totales
    print("\n========= RESULTADO =========\n")
    print(f"Valor óptimo: {objective}, Variables de decisión: {cols}, Restricciones totales: {rows}\n")
    print("Asignaciones de autobuses a franjas:")

    # Diccionario para almacenar asignaciones
    asignaciones = {}

    # Leer columnas de asignacion y guardarlas para imprimir por pantalla
    lineas = contenido.splitlines()
    for i, linea in enumerate(lineas):
        # Buscamos las asignaciones en el archivo de solución de GLPK
        match = re.match(r'\s*\d+\s+asignacion\[(a\d+),(s\d+)\]', linea)
        if match:
            bus, franja = match.groups()
            if i+1 < len(lineas):
                act_line = lineas[i+1]
                act_parts = act_line.split()
                if len(act_parts) >= 2:
                    try:
                        activity = int(act_parts[1])
                        if activity == 1:
                            asignaciones[bus] = franja
                    except ValueError:
                        pass

    # Mostrar todas las asignaciones y los no asignados
    for j in range(m):
        bus = f"a{j+1}"
        if bus in asignaciones:
            print(f"Autobús {bus} asignado a Franja {asignaciones[bus]}")
        else:
            print(f"Autobús {bus} no asignado")

# Salta error si hay algun error en la ejecución de GLPK
except FileNotFoundError:
    print("Error: no se ha generado 'sol.txt'. Revisa errores de GLPK.")